Project: Construction Management System using PHP/MySQL

About
The Construction Management System is simple PHP/MySQL project that will help construction businesses to manage the records and status of each project they hanlde. This project organizes the construction company's project records with the status of each part of category of the development such as the layout,landscape and etc, which this feature is dynamic to this system, which means that the category or division list can be manage by the system user. The project management system also manages the teams/workers for each project. The display also the progress of each category/divion in each project in this will be manage by the system user where as this feature will help the company to monitor the progress of the project by divisions and overall. The system display a simple reminder/notification in the homepage for the upcoming deadlines which displays only when a project is still going and the current date is within the 15 days before the deadline, and also display the project that is still going and already pass the deadline.
Features:
-Login Page
    -The page where system user will submit their system credentials to access the system.
-Home Page
    -The page where the system user will be redirected by default after logging in.
-Employee List Page
    -The page where all compny's employees are listed and managed.
-Position Page
    -the page where can system user manages the list of employees position.
-Project Division Page
    -The page where can system user manages the list of project divisions.
-Project Team Page
    -The page where project teams are listed and can be manage by the system page.
-Project List Page
    -The page where all projects are listed and manage along with their details and status.
-Users Page
    -The page where can system admin manages the list of system users.
How to install:
